import asyncHandler from 'express-async-handler';
import Prescription from '../models/Prescription.js';
import Appointment from '../models/Appointment.js';

// @desc Create prescription (doctor creates for appointment)
// @route POST /api/prescriptions
// @access Private (doctor)
export const createPrescription = asyncHandler(async (req, res) => {
  const { appointmentId, medications, instructions } = req.body;

  if (!appointmentId || !Array.isArray(medications) || medications.length === 0) {
    res.status(400);
    throw new Error('Appointment ID and at least one medication are required');
  }

  const appointment = await Appointment.findById(appointmentId);
  if (!appointment) {
    res.status(404);
    throw new Error('Appointment not found');
  }

  // Only assigned doctor can create prescription
  if (!(req.user.role === 'doctor' && appointment.doctor.equals(req.user._id))) {
    res.status(403);
    throw new Error('Not authorized to create prescription for this appointment');
  }

  const prescription = new Prescription({
    appointment: appointmentId,
    medications,
    instructions: instructions || ''
  });

  const createdPrescription = await prescription.save();

  res.status(201).json(createdPrescription);
});

// @desc Get prescriptions by patient user ID
// @route GET /api/prescriptions/user/:userId
// @access Private (patient self or doctor/admin)
export const getPrescriptionsByUser = asyncHandler(async (req, res) => {
  const userId = req.params.userId;

  // Patient can only get own prescriptions
  if (req.user.role === 'patient' && req.user._id.toString() !== userId) {
    res.status(403);
    throw new Error('Not authorized to access these prescriptions');
  }

  // Find all prescriptions where appointment.patient == userId
  const prescriptions = await Prescription.find()
    .populate({
      path: 'appointment',
      match: { patient: userId },
      populate: [
        { path: 'doctor', select: 'name email' },
        { path: 'patient', select: 'name email' }
      ]
    })
    .sort({ issuedDate: -1 });

  // Filter out prescriptions with null appointment (due to match)
  const filteredPrescriptions = prescriptions.filter((p) => p.appointment !== null);

  res.json(filteredPrescriptions);
});

// @desc Update prescription (doctor)
// @route PUT /api/prescriptions/:id
// @access Private (doctor)
export const updatePrescription = asyncHandler(async (req, res) => {
  const prescription = await Prescription.findById(req.params.id).populate('appointment');

  if (!prescription) {
    res.status(404);
    throw new Error('Prescription not found');
  }

  if (!(req.user.role === 'doctor' && prescription.appointment.doctor.equals(req.user._id))) {
    res.status(403);
    throw new Error('Not authorized to update this prescription');
  }

  const { medications, instructions } = req.body;

  if (medications && Array.isArray(medications) && medications.length > 0) {
    prescription.medications = medications;
  }

  if (instructions !== undefined) {
    prescription.instructions = instructions;
  }

  const updatedPrescription = await prescription.save();

  res.json(updatedPrescription);
});

// @desc Delete prescription (doctor/admin)
// @route DELETE /api/prescriptions/:id
// @access Private (doctor/admin)
export const deletePrescription = asyncHandler(async (req, res) => {
  const prescription = await Prescription.findById(req.params.id).populate('appointment');
  if (!prescription) {
    res.status(404);
    throw new Error('Prescription not found');
  }

  if (
    req.user.role !== 'admin' &&
    !(req.user.role === 'doctor' && prescription.appointment.doctor.equals(req.user._id))
  ) {
    res.status(403);
    throw new Error('Not authorized to delete this prescription');
  }

  await prescription.remove();
  res.json({ message: 'Prescription deleted' });
});
