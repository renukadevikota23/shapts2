import asyncHandler from 'express-async-handler';
import Appointment from '../models/Appointment.js';
import User from '../models/User.js';

// @desc Create appointment (patient books doctor)
// @route POST /api/appointments
// @access Private (patient)
export const createAppointment = asyncHandler(async (req, res) => {
  const { doctorId, appointmentDate, notes } = req.body;

  if (!doctorId || !appointmentDate) {
    res.status(400);
    throw new Error('Doctor and appointment date are required');
  }

  // Validate doctor exists and is role doctor
  const doctor = await User.findOne({ _id: doctorId, role: 'doctor' });
  if (!doctor) {
    res.status(400);
    throw new Error('Doctor not found');
  }

  const appointmentDateObj = new Date(appointmentDate);
  if (isNaN(appointmentDateObj.getTime())) {
    res.status(400);
    throw new Error('Invalid appointment date');
  }

  if (appointmentDateObj < new Date()) {
    res.status(400);
    throw new Error('Appointment date must be in the future');
  }

  const appointment = new Appointment({
    patient: req.user._id,
    doctor: doctorId,
    appointmentDate: appointmentDateObj,
    notes: notes || ''
  });

  const createdAppointment = await appointment.save();

  res.status(201).json(createdAppointment);
});

// @desc Get appointments filtered by user role
// @route GET /api/appointments
// @access Private
export const getAppointments = asyncHandler(async (req, res) => {
  let filter = {};
  if (req.user.role === 'patient') {
    filter.patient = req.user._id;
  } else if (req.user.role === 'doctor') {
    filter.doctor = req.user._id;
  } // admin can see all

  const appointments = await Appointment.find(filter)
    .populate('patient', 'name email')
    .populate('doctor', 'name email')
    .sort({ appointmentDate: 1 });

  res.json(appointments);
});

// @desc Update appointment status (doctor/admin)
// @route PUT /api/appointments/:id/status
// @access Private (doctor/admin)
export const updateAppointmentStatus = asyncHandler(async (req, res) => {
  const appointment = await Appointment.findById(req.params.id);
  if (!appointment) {
    res.status(404);
    throw new Error('Appointment not found');
  }

  // Only doctor assigned or admin
  if (
    req.user.role !== 'admin' &&
    !(req.user.role === 'doctor' && appointment.doctor.equals(req.user._id))
  ) {
    res.status(403);
    throw new Error('Not authorized to update appointment status');
  }

  const { status } = req.body;
  if (!['scheduled', 'completed', 'cancelled'].includes(status)) {
    res.status(400);
    throw new Error('Invalid status');
  }

  appointment.status = status;
  await appointment.save();

  res.json(appointment);
});

// @desc Cancel appointment (patient)
// @route DELETE /api/appointments/:id
// @access Private (patient)
export const cancelAppointment = asyncHandler(async (req, res) => {
  const appointment = await Appointment.findById(req.params.id);
  if (!appointment) {
    res.status(404);
    throw new Error('Appointment not found');
  }

  if (!appointment.patient.equals(req.user._id)) {
    res.status(403);
    throw new Error('Not authorized to cancel this appointment');
  }

  if (appointment.status === 'cancelled') {
    res.status(400);
    throw new Error('Appointment is already cancelled');
  }

  appointment.status = 'cancelled';
  await appointment.save();

  res.json({ message: 'Appointment cancelled' });
});
