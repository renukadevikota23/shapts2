const CREATE_PRESCRIPTION_REQUEST = 'prescriptions/CREATE_PRESCRIPTION_REQUEST';
const CREATE_PRESCRIPTION_SUCCESS = 'prescriptions/CREATE_PRESCRIPTION_SUCCESS';
const CREATE_PRESCRIPTION_FAIL = 'prescriptions/CREATE_PRESCRIPTION_FAIL';

const FETCH_PRESCRIPTIONS_REQUEST = 'prescriptions/FETCH_PRESCRIPTIONS_REQUEST';
const FETCH_PRESCRIPTIONS_SUCCESS = 'prescriptions/FETCH_PRESCRIPTIONS_SUCCESS';
const FETCH_PRESCRIPTIONS_FAIL = 'prescriptions/FETCH_PRESCRIPTIONS_FAIL';

const UPDATE_PRESCRIPTION_REQUEST = 'prescriptions/UPDATE_PRESCRIPTION_REQUEST';
const UPDATE_PRESCRIPTION_SUCCESS = 'prescriptions/UPDATE_PRESCRIPTION_SUCCESS';
const UPDATE_PRESCRIPTION_FAIL = 'prescriptions/UPDATE_PRESCRIPTION_FAIL';

const DELETE_PRESCRIPTION_REQUEST = 'prescriptions/DELETE_PRESCRIPTION_REQUEST';
const DELETE_PRESCRIPTION_SUCCESS = 'prescriptions/DELETE_PRESCRIPTION_SUCCESS';
const DELETE_PRESCRIPTION_FAIL = 'prescriptions/DELETE_PRESCRIPTION_FAIL';

const initialState = {
  prescriptions: [],
  loading: false,
  error: null
};

export const createPrescription = (prescriptionData) => async (dispatch) => {
  try {
    dispatch({ type: CREATE_PRESCRIPTION_REQUEST });
    const res = await import('../api/prescriptionApi.js').then((mod) =>
      mod.createPrescription(prescriptionData)
    );
    dispatch({ type: CREATE_PRESCRIPTION_SUCCESS, payload: res });
  } catch (error) {
    dispatch({
      type: CREATE_PRESCRIPTION_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const fetchUserPrescriptions = (userId) => async (dispatch) => {
  try {
    dispatch({ type: FETCH_PRESCRIPTIONS_REQUEST });
    const res = await import('../api/prescriptionApi.js').then((mod) =>
      mod.fetchUserPrescriptions(userId)
    );
    dispatch({ type: FETCH_PRESCRIPTIONS_SUCCESS, payload: res });
  } catch (error) {
    dispatch({
      type: FETCH_PRESCRIPTIONS_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const updatePrescription = (id, prescriptionData) => async (dispatch) => {
  try {
    dispatch({ type: UPDATE_PRESCRIPTION_REQUEST });
    const res = await import('../api/prescriptionApi.js').then((mod) =>
      mod.updatePrescription(id, prescriptionData)
    );
    dispatch({ type: UPDATE_PRESCRIPTION_SUCCESS, payload: res });
  } catch (error) {
    dispatch({
      type: UPDATE_PRESCRIPTION_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const deletePrescription = (id) => async (dispatch) => {
  try {
    dispatch({ type: DELETE_PRESCRIPTION_REQUEST });
    await import('../api/prescriptionApi.js').then((mod) => mod.deletePrescription(id));
    dispatch({ type: DELETE_PRESCRIPTION_SUCCESS, payload: id });
  } catch (error) {
    dispatch({
      type: DELETE_PRESCRIPTION_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const prescriptionReducer = (state = initialState, action) => {
  switch (action.type) {
    case CREATE_PRESCRIPTION_REQUEST:
    case FETCH_PRESCRIPTIONS_REQUEST:
    case UPDATE_PRESCRIPTION_REQUEST:
    case DELETE_PRESCRIPTION_REQUEST:
      return { ...state, loading: true, error: null };
    case CREATE_PRESCRIPTION_SUCCESS:
      return {
        ...state,
        loading: false,
        prescriptions: [...state.prescriptions, action.payload],
        error: null
      };
    case FETCH_PRESCRIPTIONS_SUCCESS:
      return { ...state, loading: false, prescriptions: action.payload, error: null };
    case UPDATE_PRESCRIPTION_SUCCESS:
      return {
        ...state,
        loading: false,
        prescriptions: state.prescriptions.map((p) =>
          p._id === action.payload._id ? action.payload : p
        ),
        error: null
      };
    case DELETE_PRESCRIPTION_SUCCESS:
      return {
        ...state,
        loading: false,
        prescriptions: state.prescriptions.filter((p) => p._id !== action.payload),
        error: null
      };
    case CREATE_PRESCRIPTION_FAIL:
    case FETCH_PRESCRIPTIONS_FAIL:
    case UPDATE_PRESCRIPTION_FAIL:
    case DELETE_PRESCRIPTION_FAIL:
      return { ...state, loading: false, error: action.payload };
    default:
      return state;
  }
};
