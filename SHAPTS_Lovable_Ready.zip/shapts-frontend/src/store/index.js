import { combineReducers, createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import { authReducer } from './authSlice';
import { userReducer } from './userSlice';
import { appointmentReducer } from './appointmentSlice';
import { prescriptionReducer } from './prescriptionSlice';

const rootReducer = combineReducers({
  auth: authReducer,
  user: userReducer,
  appointments: appointmentReducer,
  prescriptions: prescriptionReducer
});

const store = createStore(rootReducer, applyMiddleware(thunk));

export default store;
