const LOGIN_REQUEST = 'auth/LOGIN_REQUEST';
const LOGIN_SUCCESS = 'auth/LOGIN_SUCCESS';
const LOGIN_FAIL = 'auth/LOGIN_FAIL';
const LOGOUT = 'auth/LOGOUT';
const REGISTER_REQUEST = 'auth/REGISTER_REQUEST';
const REGISTER_SUCCESS = 'auth/REGISTER_SUCCESS';
const REGISTER_FAIL = 'auth/REGISTER_FAIL';

const initialState = {
  token: localStorage.getItem('token') || null,
  user: null,
  loading: false,
  error: null
};

export const login = (credentials) => async (dispatch) => {
  try {
    dispatch({ type: LOGIN_REQUEST });
    const res = await import('../api/authApi.js').then((mod) =>
      mod.loginUser(credentials)
    );
    dispatch({ type: LOGIN_SUCCESS, payload: res });
    localStorage.setItem('token', res.token);
  } catch (error) {
    dispatch({
      type: LOGIN_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const register = (userData) => async (dispatch) => {
  try {
    dispatch({ type: REGISTER_REQUEST });
    const res = await import('../api/authApi.js').then((mod) =>
      mod.registerUser(userData)
    );
    dispatch({ type: REGISTER_SUCCESS, payload: res });
    localStorage.setItem('token', res.token);
  } catch (error) {
    dispatch({
      type: REGISTER_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const logout = () => (dispatch) => {
  localStorage.removeItem('token');
  dispatch({ type: LOGOUT });
};

export const authReducer = (state = initialState, action) => {
  switch (action.type) {
    case LOGIN_REQUEST:
    case REGISTER_REQUEST:
      return { ...state, loading: true, error: null };
    case LOGIN_SUCCESS:
    case REGISTER_SUCCESS:
      return {
        ...state,
        loading: false,
        token: action.payload.token,
        user: {
          _id: action.payload._id,
          name: action.payload.name,
          email: action.payload.email,
          role: action.payload.role
        },
        error: null
      };
    case LOGIN_FAIL:
    case REGISTER_FAIL:
      return { ...state, loading: false, error: action.payload };
    case LOGOUT:
      return { ...initialState, token: null, user: null };
    default:
      return state;
  }
};
