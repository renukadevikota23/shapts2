const CREATE_APPOINTMENT_REQUEST = 'appointments/CREATE_APPOINTMENT_REQUEST';
const CREATE_APPOINTMENT_SUCCESS = 'appointments/CREATE_APPOINTMENT_SUCCESS';
const CREATE_APPOINTMENT_FAIL = 'appointments/CREATE_APPOINTMENT_FAIL';

const FETCH_APPOINTMENTS_REQUEST = 'appointments/FETCH_APPOINTMENTS_REQUEST';
const FETCH_APPOINTMENTS_SUCCESS = 'appointments/FETCH_APPOINTMENTS_SUCCESS';
const FETCH_APPOINTMENTS_FAIL = 'appointments/FETCH_APPOINTMENTS_FAIL';

const UPDATE_APPOINTMENT_STATUS_REQUEST = 'appointments/UPDATE_STATUS_REQUEST';
const UPDATE_APPOINTMENT_STATUS_SUCCESS = 'appointments/UPDATE_STATUS_SUCCESS';
const UPDATE_APPOINTMENT_STATUS_FAIL = 'appointments/UPDATE_STATUS_FAIL';

const CANCEL_APPOINTMENT_REQUEST = 'appointments/CANCEL_APPOINTMENT_REQUEST';
const CANCEL_APPOINTMENT_SUCCESS = 'appointments/CANCEL_APPOINTMENT_SUCCESS';
const CANCEL_APPOINTMENT_FAIL = 'appointments/CANCEL_APPOINTMENT_FAIL';

const initialState = {
  appointments: [],
  loading: false,
  error: null
};

export const createAppointment = (appointmentData) => async (dispatch) => {
  try {
    dispatch({ type: CREATE_APPOINTMENT_REQUEST });
    const res = await import('../api/appointmentApi.js').then((mod) =>
      mod.createAppointment(appointmentData)
    );
    dispatch({ type: CREATE_APPOINTMENT_SUCCESS, payload: res });
  } catch (error) {
    dispatch({
      type: CREATE_APPOINTMENT_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const fetchAppointments = () => async (dispatch) => {
  try {
    dispatch({ type: FETCH_APPOINTMENTS_REQUEST });
    const res = await import('../api/appointmentApi.js').then((mod) => mod.fetchAppointments());
    dispatch({ type: FETCH_APPOINTMENTS_SUCCESS, payload: res });
  } catch (error) {
    dispatch({
      type: FETCH_APPOINTMENTS_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const updateAppointmentStatus = (id, status) => async (dispatch) => {
  try {
    dispatch({ type: UPDATE_APPOINTMENT_STATUS_REQUEST });
    const res = await import('../api/appointmentApi.js').then((mod) =>
      mod.updateAppointmentStatus(id, status)
    );
    dispatch({ type: UPDATE_APPOINTMENT_STATUS_SUCCESS, payload: res });
  } catch (error) {
    dispatch({
      type: UPDATE_APPOINTMENT_STATUS_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const cancelAppointment = (id) => async (dispatch) => {
  try {
    dispatch({ type: CANCEL_APPOINTMENT_REQUEST });
    await import('../api/appointmentApi.js').then((mod) => mod.cancelAppointment(id));
    dispatch({ type: CANCEL_APPOINTMENT_SUCCESS, payload: id });
  } catch (error) {
    dispatch({
      type: CANCEL_APPOINTMENT_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const appointmentReducer = (state = initialState, action) => {
  switch (action.type) {
    case CREATE_APPOINTMENT_REQUEST:
    case FETCH_APPOINTMENTS_REQUEST:
    case UPDATE_APPOINTMENT_STATUS_REQUEST:
    case CANCEL_APPOINTMENT_REQUEST:
      return { ...state, loading: true, error: null };
    case CREATE_APPOINTMENT_SUCCESS:
      return {
        ...state,
        loading: false,
        appointments: [...state.appointments, action.payload],
        error: null
      };
    case FETCH_APPOINTMENTS_SUCCESS:
      return {
        ...state,
        loading: false,
        appointments: action.payload,
        error: null
      };
    case UPDATE_APPOINTMENT_STATUS_SUCCESS:
      return {
        ...state,
        loading: false,
        appointments: state.appointments.map((appt) =>
          appt._id === action.payload._id ? action.payload : appt
        ),
        error: null
      };
    case CANCEL_APPOINTMENT_SUCCESS:
      return {
        ...state,
        loading: false,
        appointments: state.appointments.map((appt) =>
          appt._id === action.payload ? { ...appt, status: 'cancelled' } : appt
        ),
        error: null
      };
    case CREATE_APPOINTMENT_FAIL:
    case FETCH_APPOINTMENTS_FAIL:
    case UPDATE_APPOINTMENT_STATUS_FAIL:
    case CANCEL_APPOINTMENT_FAIL:
      return { ...state, loading: false, error: action.payload };
    default:
      return state;
  }
};
