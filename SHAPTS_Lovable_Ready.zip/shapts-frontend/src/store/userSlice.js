const FETCH_PROFILE_REQUEST = 'user/FETCH_PROFILE_REQUEST';
const FETCH_PROFILE_SUCCESS = 'user/FETCH_PROFILE_SUCCESS';
const FETCH_PROFILE_FAIL = 'user/FETCH_PROFILE_FAIL';

const UPDATE_PROFILE_REQUEST = 'user/UPDATE_PROFILE_REQUEST';
const UPDATE_PROFILE_SUCCESS = 'user/UPDATE_PROFILE_SUCCESS';
const UPDATE_PROFILE_FAIL = 'user/UPDATE_PROFILE_FAIL';

const FETCH_USERS_REQUEST = 'user/FETCH_USERS_REQUEST';
const FETCH_USERS_SUCCESS = 'user/FETCH_USERS_SUCCESS';
const FETCH_USERS_FAIL = 'user/FETCH_USERS_FAIL';

const DELETE_USER_REQUEST = 'user/DELETE_USER_REQUEST';
const DELETE_USER_SUCCESS = 'user/DELETE_USER_SUCCESS';
const DELETE_USER_FAIL = 'user/DELETE_USER_FAIL';

const initialState = {
  profile: null,
  usersList: [],
  loadingProfile: false,
  loadingUsers: false,
  errorProfile: null,
  errorUsers: null,
  deleteUserStatus: null
};

export const fetchUserProfile = () => async (dispatch) => {
  try {
    dispatch({ type: FETCH_PROFILE_REQUEST });
    const res = await import('../api/userApi.js').then((mod) => mod.getUserProfile());
    dispatch({ type: FETCH_PROFILE_SUCCESS, payload: res });
  } catch (error) {
    dispatch({
      type: FETCH_PROFILE_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const updateUserProfile = (profileData) => async (dispatch) => {
  try {
    dispatch({ type: UPDATE_PROFILE_REQUEST });
    const res = await import('../api/userApi.js').then((mod) =>
      mod.updateUserProfile(profileData)
    );
    dispatch({ type: UPDATE_PROFILE_SUCCESS, payload: res });
  } catch (error) {
    dispatch({
      type: UPDATE_PROFILE_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const fetchUsers = (pageNumber = 1) => async (dispatch) => {
  try {
    dispatch({ type: FETCH_USERS_REQUEST });
    const res = await import('../api/userApi.js').then((mod) => mod.fetchUsers(pageNumber));
    dispatch({ type: FETCH_USERS_SUCCESS, payload: res });
  } catch (error) {
    dispatch({
      type: FETCH_USERS_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const deleteUser = (id) => async (dispatch) => {
  try {
    dispatch({ type: DELETE_USER_REQUEST });
    await import('../api/userApi.js').then((mod) => mod.deleteUser(id));
    dispatch({ type: DELETE_USER_SUCCESS, payload: id });
  } catch (error) {
    dispatch({
      type: DELETE_USER_FAIL,
      payload: error.response?.data?.message || error.message
    });
  }
};

export const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_PROFILE_REQUEST:
      return { ...state, loadingProfile: true, errorProfile: null };
    case FETCH_PROFILE_SUCCESS:
      return { ...state, loadingProfile: false, profile: action.payload };
    case FETCH_PROFILE_FAIL:
      return { ...state, loadingProfile: false, errorProfile: action.payload };

    case UPDATE_PROFILE_REQUEST:
      return { ...state, loadingProfile: true, errorProfile: null };
    case UPDATE_PROFILE_SUCCESS:
      return { ...state, loadingProfile: false, profile: action.payload };
    case UPDATE_PROFILE_FAIL:
      return { ...state, loadingProfile: false, errorProfile: action.payload };

    case FETCH_USERS_REQUEST:
      return { ...state, loadingUsers: true, errorUsers: null };
    case FETCH_USERS_SUCCESS:
      return { ...state, loadingUsers: false, usersList: action.payload.users };
    case FETCH_USERS_FAIL:
      return { ...state, loadingUsers: false, errorUsers: action.payload };

    case DELETE_USER_REQUEST:
      return { ...state, deleteUserStatus: 'loading', errorUsers: null };
    case DELETE_USER_SUCCESS:
      return {
        ...state,
        deleteUserStatus: 'success',
        usersList: state.usersList.filter((user) => user._id !== action.payload)
      };
    case DELETE_USER_FAIL:
      return { ...state, deleteUserStatus: 'fail', errorUsers: action.payload };

    default:
      return state;
  }
};
