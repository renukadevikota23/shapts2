import apiClient from './apiClient';

export const getUserProfile = async () => {
  const response = await apiClient.get('/api/users/profile');
  return response.data;
};

export const updateUserProfile = async (profileData) => {
  const response = await apiClient.put('/api/users/profile', profileData);
  return response.data;
};

export const fetchUsers = async (pageNumber = 1) => {
  const response = await apiClient.get(`/api/users?pageNumber=${pageNumber}`);
  return response.data;
};

export const deleteUser = async (id) => {
  const response = await apiClient.delete(`/api/users/${id}`);
  return response.data;
};
