import apiClient from './apiClient';

export const createPrescription = async (prescriptionData) => {
  const response = await apiClient.post('/api/prescriptions', prescriptionData);
  return response.data;
};

export const fetchUserPrescriptions = async (userId) => {
  const response = await apiClient.get(`/api/prescriptions/user/${userId}`);
  return response.data;
};

export const updatePrescription = async (id, prescriptionData) => {
  const response = await apiClient.put(`/api/prescriptions/${id}`, prescriptionData);
  return response.data;
};

export const deletePrescription = async (id) => {
  const response = await apiClient.delete(`/api/prescriptions/${id}`);
  return response.data;
};
