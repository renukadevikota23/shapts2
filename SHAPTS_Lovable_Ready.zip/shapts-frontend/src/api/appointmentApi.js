import apiClient from './apiClient';

export const createAppointment = async (appointmentData) => {
  const response = await apiClient.post('/api/appointments', appointmentData);
  return response.data;
};

export const fetchAppointments = async () => {
  const response = await apiClient.get('/api/appointments');
  return response.data;
};

export const updateAppointmentStatus = async (id, status) => {
  const response = await apiClient.put(`/api/appointments/${id}/status`, { status });
  return response.data;
};

export const cancelAppointment = async (id) => {
  const response = await apiClient.delete(`/api/appointments/${id}`);
  return response.data;
};
