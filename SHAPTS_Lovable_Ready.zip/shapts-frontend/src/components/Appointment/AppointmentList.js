import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { updateAppointmentStatus, cancelAppointment } from '../../store/appointmentSlice';
import { USER_ROLES } from '../../utils/constants';

const AppointmentList = () => {
  const dispatch = useDispatch();
  const { appointments, loading, error } = useSelector((state) => state.appointments);
  const user = useSelector((state) => state.auth.user);
  const [filterStatus, setFilterStatus] = useState('');

  const filteredAppointments = filterStatus
    ? appointments.filter((appt) => appt.status === filterStatus)
    : appointments;

  const handleStatusChange = (id, status) => {
    dispatch(updateAppointmentStatus(id, status));
  };

  const handleCancel = (id) => {
    if (window.confirm('Are you sure you want to cancel this appointment?')) {
      dispatch(cancelAppointment(id));
    }
  };

  return (
    <section>
      <h2>Appointments</h2>
      <label htmlFor="statusFilter">Filter by status:</label>
      <select
        id="statusFilter"
        value={filterStatus}
        onChange={(e) => setFilterStatus(e.target.value)}
        style={{ marginLeft: '0.5rem' }}
      >
        <option value="">All</option>
        <option value="scheduled">Scheduled</option>
        <option value="completed">Completed</option>
        <option value="cancelled">Cancelled</option>
      </select>

      {loading && <p>Loading appointments...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {!loading && filteredAppointments.length === 0 && <p>No appointments found.</p>}
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {filteredAppointments.map((appt) => (
          <li
            key={appt._id}
            style={{
              border: '1px solid #ccc',
              margin: '0.5rem 0',
              padding: '0.5rem',
              borderRadius: '4px'
            }}
          >
            <p>
              <strong>Date:</strong>{' '}
              {new Date(appt.appointmentDate).toLocaleString(undefined, {
                dateStyle: 'medium',
                timeStyle: 'short'
              })}
            </p>
            <p>
              <strong>Patient:</strong> {appt.patient?.name || 'N/A'} ({appt.patient?.email || 'N/A'})
            </p>
            <p>
              <strong>Doctor:</strong> {appt.doctor?.name || 'N/A'} ({appt.doctor?.email || 'N/A'})
            </p>
            <p>
              <strong>Status:</strong> {appt.status}
            </p>
            <p>
              <strong>Notes:</strong> {appt.notes || 'None'}
            </p>

            {(user.role === USER_ROLES.DOCTOR || user.role === USER_ROLES.ADMIN) && (
              <div>
                <label htmlFor={`status-${appt._id}`}>Update status:</label>
                <select
                  id={`status-${appt._id}`}
                  value={appt.status}
                  onChange={(e) => handleStatusChange(appt._id, e.target.value)}
                >
                  <option value="scheduled">Scheduled</option>
                  <option value="completed">Completed</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>
            )}

            {user.role === USER_ROLES.PATIENT && appt.status !== 'cancelled' && (
              <button onClick={() => handleCancel(appt._id)}>Cancel Appointment</button>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
};

export default AppointmentList;
