import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { createAppointment, fetchAppointments } from '../../store/appointmentSlice';
import { fetchUsers } from '../../store/userSlice';

const AppointmentForm = () => {
  const dispatch = useDispatch();
  const { usersList } = useSelector((state) => state.user);
  const { loading } = useSelector((state) => state.appointments);

  const [doctorId, setDoctorId] = useState('');
  const [appointmentDate, setAppointmentDate] = useState('');
  const [notes, setNotes] = useState('');
  const [validationErrors, setValidationErrors] = useState({});

  useEffect(() => {
    dispatch(fetchUsers());
  }, [dispatch]);

  const handleSubmit = (e) => {
    e.preventDefault();

    const errors = {};
    if (!doctorId) errors.doctorId = 'Please select a doctor';
    if (!appointmentDate) errors.appointmentDate = 'Please select an appointment date';

    setValidationErrors(errors);

    if (Object.keys(errors).length === 0) {
      dispatch(createAppointment({ doctorId, appointmentDate, notes }));
      setDoctorId('');
      setAppointmentDate('');
      setNotes('');
      dispatch(fetchAppointments());
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      <h2>Book New Appointment</h2>
      <div>
        <label htmlFor="doctor">Doctor:</label>
        <select
          id="doctor"
          value={doctorId}
          onChange={(e) => setDoctorId(e.target.value)}
          required
          aria-invalid={!!validationErrors.doctorId}
          aria-describedby="doctor-error"
        >
          <option value="">Select doctor</option>
          {usersList
            .filter((user) => user.role === 'doctor')
            .map((doctor) => (
              <option key={doctor._id} value={doctor._id}>
                {doctor.name} ({doctor.email})
              </option>
            ))}
        </select>
        {validationErrors.doctorId && (
          <div id="doctor-error" style={{ color: 'red' }}>
            {validationErrors.doctorId}
          </div>
        )}
      </div>
      <div>
        <label htmlFor="appointmentDate">Date and Time:</label>
        <input
          id="appointmentDate"
          type="datetime-local"
          value={appointmentDate}
          onChange={(e) => setAppointmentDate(e.target.value)}
          required
          aria-invalid={!!validationErrors.appointmentDate}
          aria-describedby="appointmentDate-error"
          min={new Date().toISOString().slice(0, 16)}
        />
        {validationErrors.appointmentDate && (
          <div id="appointmentDate-error" style={{ color: 'red' }}>
            {validationErrors.appointmentDate}
          </div>
        )}
      </div>
      <div>
        <label htmlFor="notes">Notes (optional):</label>
        <textarea
          id="notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
          maxLength={500}
        />
      </div>
      <button type="submit" disabled={loading}>
        {loading ? 'Booking...' : 'Book Appointment'}
      </button>
    </form>
  );
};

export default AppointmentForm;
