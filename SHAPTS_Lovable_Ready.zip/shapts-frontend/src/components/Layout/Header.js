import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import useAuth from '../../hooks/useAuth';

const Header = () => {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header style={{ backgroundColor: '#004d99', padding: '1rem', color: '#fff' }}>
      <nav style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Link to="/" style={{ color: '#fff', textDecoration: 'none', fontWeight: 'bold', fontSize: '1.5rem' }}>
          Shapts
        </Link>
        <div>
          {!isAuthenticated ? (
            <>
              <Link to="/login" style={{ color: '#fff', marginRight: '1rem' }}>
                Login
              </Link>
              <Link to="/register" style={{ color: '#fff' }}>
                Register
              </Link>
            </>
          ) : (
            <>
              <Link to="/dashboard" style={{ color: '#fff', marginRight: '1rem' }}>
                Dashboard
              </Link>
              <Link to="/appointments" style={{ color: '#fff', marginRight: '1rem' }}>
                Appointments
              </Link>
              <Link to="/prescriptions" style={{ color: '#fff', marginRight: '1rem' }}>
                Prescriptions
              </Link>
              <span style={{ marginRight: '1rem' }}>Hello, {user?.name}</span>
              <button onClick={handleLogout} style={{ cursor: 'pointer' }}>
                Logout
              </button>
            </>
          )}
        </div>
      </nav>
    </header>
  );
};

export default Header;
