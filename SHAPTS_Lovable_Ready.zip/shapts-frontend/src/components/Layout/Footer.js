import React from 'react';

const Footer = () => (
  <footer
    style={{
      backgroundColor: '#f0f0f0',
      padding: '1rem',
      textAlign: 'center',
      fontSize: '0.9rem',
      color: '#555',
      marginTop: 'auto'
    }}
  >
    &copy; {new Date().getFullYear()} Shapts Healthcare. Contact: support@shapts.com
  </footer>
);

export default Footer;
