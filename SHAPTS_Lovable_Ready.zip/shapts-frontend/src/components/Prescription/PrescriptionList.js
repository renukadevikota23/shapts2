import React from 'react';
import { useSelector } from 'react-redux';

const PrescriptionList = () => {
  const { prescriptions, loading, error } = useSelector((state) => state.prescriptions);

  return (
    <section>
      <h2>Prescriptions</h2>
      {loading && <p>Loading prescriptions...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {prescriptions.length === 0 && !loading && <p>No prescriptions found.</p>}
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {prescriptions.map((prescription) => (
          <li
            key={prescription._id}
            style={{
              border: '1px solid #ccc',
              margin: '0.5rem 0',
              padding: '0.5rem',
              borderRadius: '4px'
            }}
          >
            <p>
              <strong>Issued Date:</strong>{' '}
              {new Date(prescription.issuedDate).toLocaleDateString(undefined, {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </p>
            <p>
              <strong>Appointment Date:</strong>{' '}
              {prescription.appointment
                ? new Date(prescription.appointment.appointmentDate).toLocaleString()
                : 'N/A'}
            </p>
            <p>
              <strong>Medications:</strong>
            </p>
            <ul>
              {prescription.medications.map((med, idx) => (
                <li key={idx}>
                  {med.name} - {med.dosage} - {med.frequency}
                </li>
              ))}
            </ul>
            <p>
              <strong>Instructions:</strong> {prescription.instructions || 'None'}
            </p>
          </li>
        ))}
      </ul>
    </section>
  );
};

export default PrescriptionList;
