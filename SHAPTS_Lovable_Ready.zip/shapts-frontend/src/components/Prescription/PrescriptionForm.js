import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { createPrescription, updatePrescription } from '../../store/prescriptionSlice';
import { fetchAppointments } from '../../store/appointmentSlice';

const PrescriptionForm = ({ existingPrescription, onClose }) => {
  const dispatch = useDispatch();
  const { appointments } = useSelector((state) => state.appointments);
  const [appointmentId, setAppointmentId] = useState(existingPrescription?.appointment?._id || '');
  const [medications, setMedications] = useState(
    existingPrescription?.medications || [{ name: '', dosage: '', frequency: '' }]
  );
  const [instructions, setInstructions] = useState(existingPrescription?.instructions || '');
  const [validationErrors, setValidationErrors] = useState({});

  useEffect(() => {
    dispatch(fetchAppointments());
  }, [dispatch]);

  const handleMedicationChange = (index, field, value) => {
    const meds = [...medications];
    meds[index][field] = value;
    setMedications(meds);
  };

  const handleAddMedication = () => {
    setMedications([...medications, { name: '', dosage: '', frequency: '' }]);
  };

  const handleRemoveMedication = (index) => {
    setMedications(medications.filter((_, i) => i !== index));
  };

  const validate = () => {
    const errors = {};
    if (!appointmentId) errors.appointmentId = 'Please select an appointment';
    medications.forEach((med, idx) => {
      if (!med.name) errors[`medName${idx}`] = 'Medication name required';
      if (!med.dosage) errors[`medDosage${idx}`] = 'Dosage required';
      if (!med.frequency) errors[`medFrequency${idx}`] = 'Frequency required';
    });
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    const prescriptionData = { appointmentId, medications, instructions };

    if (existingPrescription) {
      dispatch(updatePrescription(existingPrescription._id, prescriptionData));
    } else {
      dispatch(createPrescription(prescriptionData));
    }
    if (onClose) onClose();
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      <h2>{existingPrescription ? 'Edit Prescription' : 'Create Prescription'}</h2>
      <div>
        <label htmlFor="appointment">Appointment:</label>
        <select
          id="appointment"
          value={appointmentId}
          onChange={(e) => setAppointmentId(e.target.value)}
          required
          aria-invalid={!!validationErrors.appointmentId}
          aria-describedby="appointment-error"
        >
          <option value="">Select appointment</option>
          {appointments.map((appt) => (
            <option key={appt._id} value={appt._id}>
              {new Date(appt.appointmentDate).toLocaleString()} - Patient: {appt.patient?.name || 'N/A'}
            </option>
          ))}
        </select>
        {validationErrors.appointmentId && (
          <div id="appointment-error" style={{ color: 'red' }}>
            {validationErrors.appointmentId}
          </div>
        )}
      </div>
      <fieldset>
        <legend>Medications</legend>
        {medications.map((med, idx) => (
          <div key={idx} style={{ marginBottom: '1rem' }}>
            <input
              type="text"
              placeholder="Name"
              value={med.name}
              onChange={(e) => handleMedicationChange(idx, 'name', e.target.value)}
              aria-invalid={!!validationErrors[`medName${idx}`]}
              aria-describedby={`medName${idx}-error`}
              required
            />
            {validationErrors[`medName${idx}`] && (
              <div id={`medName${idx}-error`} style={{ color: 'red' }}>
                {validationErrors[`medName${idx}`]}
              </div>
            )}
            <input
              type="text"
              placeholder="Dosage"
              value={med.dosage}
              onChange={(e) => handleMedicationChange(idx, 'dosage', e.target.value)}
              aria-invalid={!!validationErrors[`medDosage${idx}`]}
              aria-describedby={`medDosage${idx}-error`}
              required
            />
            {validationErrors[`medDosage${idx}`] && (
              <div id={`medDosage${idx}-error`} style={{ color: 'red' }}>
                {validationErrors[`medDosage${idx}`]}
              </div>
            )}
            <input
              type="text"
              placeholder="Frequency"
              value={med.frequency}
              onChange={(e) => handleMedicationChange(idx, 'frequency', e.target.value)}
              aria-invalid={!!validationErrors[`medFrequency${idx}`]}
              aria-describedby={`medFrequency${idx}-error`}
              required
            />
            {validationErrors[`medFrequency${idx}`] && (
              <div id={`medFrequency${idx}-error`} style={{ color: 'red' }}>
                {validationErrors[`medFrequency${idx}`]}
              </div>
            )}
            {medications.length > 1 && (
              <button type="button" onClick={() => handleRemoveMedication(idx)}>
                Remove
              </button>
            )}
          </div>
        ))}
        <button type="button" onClick={handleAddMedication}>
          Add Medication
        </button>
      </fieldset>
      <div>
        <label htmlFor="instructions">Instructions (optional):</label>
        <textarea
          id="instructions"
          value={instructions}
          onChange={(e) => setInstructions(e.target.value)}
          rows={3}
          maxLength={500}
        />
      </div>
      <button type="submit">{existingPrescription ? 'Update Prescription' : 'Create Prescription'}</button>
      {onClose && (
        <button type="button" onClick={onClose} style={{ marginLeft: '1rem' }}>
          Cancel
        </button>
      )}
    </form>
  );
};

export default PrescriptionForm;
