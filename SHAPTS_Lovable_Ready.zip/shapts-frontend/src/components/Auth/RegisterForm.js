import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { register } from '../../store/authSlice';
import { validateEmail, validatePassword, validateRequired } from '../../utils/validators';

const RegisterForm = () => {
  const dispatch = useDispatch();
  const authState = useSelector((state) => state.auth);
  const { loading, error } = authState;

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });

  const [validationErrors, setValidationErrors] = useState({});

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.id]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const errors = {};
    if (!validateRequired(formData.name)) errors.name = 'Name is required';
    if (!validateEmail(formData.email)) errors.email = 'Invalid email address';
    if (!validatePassword(formData.password)) errors.password = 'Password must be at least 6 characters';
    if (formData.password !== formData.confirmPassword) errors.confirmPassword = 'Passwords do not match';

    setValidationErrors(errors);

    if (Object.keys(errors).length === 0) {
      dispatch(register({ name: formData.name, email: formData.email, password: formData.password }));
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      <h2>Register</h2>
      <div>
        <label htmlFor="name">Name:</label>
        <input
          id="name"
          value={formData.name}
          onChange={handleChange}
          required
          aria-invalid={!!validationErrors.name}
          aria-describedby="name-error"
        />
        {validationErrors.name && (
          <div id="name-error" style={{ color: 'red' }}>
            {validationErrors.name}
          </div>
        )}
      </div>
      <div>
        <label htmlFor="email">Email:</label>
        <input
          id="email"
          type="email"
          value={formData.email}
          onChange={handleChange}
          required
          aria-invalid={!!validationErrors.email}
          aria-describedby="email-error"
        />
        {validationErrors.email && (
          <div id="email-error" style={{ color: 'red' }}>
            {validationErrors.email}
          </div>
        )}
      </div>
      <div>
        <label htmlFor="password">Password:</label>
        <input
          id="password"
          type="password"
          value={formData.password}
          onChange={handleChange}
          required
          aria-invalid={!!validationErrors.password}
          aria-describedby="password-error"
        />
        {validationErrors.password && (
          <div id="password-error" style={{ color: 'red' }}>
            {validationErrors.password}
          </div>
        )}
      </div>
      <div>
        <label htmlFor="confirmPassword">Confirm Password:</label>
        <input
          id="confirmPassword"
          type="password"
          value={formData.confirmPassword}
          onChange={handleChange}
          required
          aria-invalid={!!validationErrors.confirmPassword}
          aria-describedby="confirmPassword-error"
        />
        {validationErrors.confirmPassword && (
          <div id="confirmPassword-error" style={{ color: 'red' }}>
            {validationErrors.confirmPassword}
          </div>
        )}
      </div>
      {error && <div style={{ color: 'red' }}>{error}</div>}
      <button type="submit" disabled={loading}>
        {loading ? 'Registering...' : 'Register'}
      </button>
    </form>
  );
};

export default RegisterForm;
