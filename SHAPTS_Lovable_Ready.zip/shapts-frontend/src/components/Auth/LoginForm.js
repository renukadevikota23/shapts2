import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { login } from '../../store/authSlice';
import { validateEmail, validatePassword } from '../../utils/validators';

const LoginForm = () => {
  const dispatch = useDispatch();
  const authState = useSelector((state) => state.auth);
  const { loading, error } = authState;

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const [validationErrors, setValidationErrors] = useState({});

  const handleSubmit = (e) => {
    e.preventDefault();

    const errors = {};
    if (!validateEmail(email)) errors.email = 'Invalid email address';
    if (!validatePassword(password)) errors.password = 'Password must be at least 6 characters';

    setValidationErrors(errors);

    if (Object.keys(errors).length === 0) {
      dispatch(login({ email, password }));
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      <h2>Login</h2>
      <div>
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value.trim())}
          required
          aria-invalid={!!validationErrors.email}
          aria-describedby="email-error"
        />
        {validationErrors.email && (
          <div id="email-error" style={{ color: 'red' }}>
            {validationErrors.email}
          </div>
        )}
      </div>
      <div>
        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          aria-invalid={!!validationErrors.password}
          aria-describedby="password-error"
        />
        {validationErrors.password && (
          <div id="password-error" style={{ color: 'red' }}>
            {validationErrors.password}
          </div>
        )}
      </div>
      {error && <div style={{ color: 'red' }}>{error}</div>}
      <button type="submit" disabled={loading}>
        {loading ? 'Logging in...' : 'Login'}
      </button>
    </form>
  );
};

export default LoginForm;
