import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import PrescriptionList from '../components/Prescription/PrescriptionList';
import PrescriptionForm from '../components/Prescription/PrescriptionForm';

const middlewares = [thunk];
const mockStore = configureStore(middlewares);

describe('Prescription Components', () => {
  let store;

  beforeEach(() => {
    store = mockStore({
      prescriptions: {
        prescriptions: [
          {
            _id: 'presc1',
            issuedDate: new Date().toISOString(),
            appointment: { appointmentDate: new Date().toISOString(), patient: { name: 'Patient One' } },
            medications: [
              { name: 'Med1', dosage: '10mg', frequency: 'Once a day' },
              { name: 'Med2', dosage: '5mg', frequency: 'Twice a day' }
            ],
            instructions: 'Take after meals'
          }
        ],
        loading: false,
        error: null
      },
      appointments: {
        appointments: [
          { _id: 'appt1', appointmentDate: new Date().toISOString(), patient: { name: 'Patient One' } }
        ]
      }
    });
  });

  test('PrescriptionList renders prescriptions', () => {
    render(
      <Provider store={store}>
        <PrescriptionList />
      </Provider>
    );

    expect(screen.getByText(/Med1/i)).toBeInTheDocument();
    expect(screen.getByText(/Take after meals/i)).toBeInTheDocument();
  });

  test('PrescriptionForm validation', () => {
    render(
      <Provider store={store}>
        <PrescriptionForm />
      </Provider>
    );

    const submitButton = screen.getByRole('button', { name: /create prescription/i });
    fireEvent.click(submitButton);

    expect(screen.getByText(/please select an appointment/i)).toBeInTheDocument();
    expect(screen.getByText(/medication name required/i)).toBeInTheDocument();
  });
});
