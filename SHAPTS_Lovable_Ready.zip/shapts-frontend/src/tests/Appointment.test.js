import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import AppointmentList from '../components/Appointment/AppointmentList';
import AppointmentForm from '../components/Appointment/AppointmentForm';

const middlewares = [thunk];
const mockStore = configureStore(middlewares);

describe('Appointment Components', () => {
  let store;

  beforeEach(() => {
    store = mockStore({
      appointments: {
        appointments: [
          {
            _id: '1',
            appointmentDate: new Date(Date.now() + 86400000).toISOString(),
            patient: { name: 'Patient One', email: 'p1@example.com' },
            doctor: { name: 'Doctor One', email: 'd1@example.com' },
            status: 'scheduled',
            notes: 'Test notes'
          }
        ],
        loading: false,
        error: null
      },
      user: {
        usersList: [
          { _id: 'd1', name: 'Doctor One', email: 'd1@example.com', role: 'doctor' }
        ]
      },
      auth: {
        user: { _id: 'p1', role: 'patient' }
      }
    });
  });

  test('AppointmentList renders appointments', () => {
    render(
      <Provider store={store}>
        <AppointmentList />
      </Provider>
    );

    expect(screen.getByText(/Patient One/i)).toBeInTheDocument();
    expect(screen.getByText(/Doctor One/i)).toBeInTheDocument();
  });

  test('AppointmentForm validation', () => {
    render(
      <Provider store={store}>
        <AppointmentForm />
      </Provider>
    );

    const submitButton = screen.getByRole('button', { name: /book appointment/i });
    fireEvent.click(submitButton);

    expect(screen.getByText(/please select a doctor/i)).toBeInTheDocument();
    expect(screen.getByText(/please select an appointment date/i)).toBeInTheDocument();
  });
});
