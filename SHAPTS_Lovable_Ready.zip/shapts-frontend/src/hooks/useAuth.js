import { useSelector, useDispatch } from 'react-redux';
import { login, logout, register } from '../store/authSlice';

const useAuth = () => {
  const dispatch = useDispatch();
  const authState = useSelector((state) => state.auth);
  const { user, token, loading, error } = authState;

  const loginUser = (credentials) => dispatch(login(credentials));
  const registerUser = (userData) => dispatch(register(userData));
  const logoutUser = () => dispatch(logout());

  return {
    user,
    token,
    loading,
    error,
    login: loginUser,
    logout: logoutUser,
    register: registerUser,
    isAuthenticated: Boolean(token)
  };
};

export default useAuth;
