import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import AppointmentList from '../components/Appointment/AppointmentList';
import AppointmentForm from '../components/Appointment/AppointmentForm';
import { fetchAppointments } from '../store/appointmentSlice';

const AppointmentsPage = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchAppointments());
  }, [dispatch]);

  return (
    <section>
      <h1>Manage Appointments</h1>
      <AppointmentForm />
      <AppointmentList />
    </section>
  );
};

export default AppointmentsPage;
