import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchAppointments } from '../store/appointmentSlice';
import { fetchUserPrescriptions } from '../store/prescriptionSlice';

const DashboardPage = () => {
  const dispatch = useDispatch();
  const { appointments, loading: apptsLoading } = useSelector((state) => state.appointments);
  const { prescriptions, loading: prescLoading } = useSelector((state) => state.prescriptions);
  const user = useSelector((state) => state.auth.user);

  useEffect(() => {
    dispatch(fetchAppointments());
    if (user) {
      dispatch(fetchUserPrescriptions(user._id));
    }
  }, [dispatch, user]);

  const upcomingAppointments = appointments
    .filter((appt) => appt.status === 'scheduled' && new Date(appt.appointmentDate) >= new Date())
    .slice(0, 5);

  const recentPrescriptions = prescriptions.slice(0, 5);

  return (
    <section>
      <h1>Dashboard</h1>
      <section>
        <h2>Upcoming Appointments</h2>
        {apptsLoading && <p>Loading appointments...</p>}
        {!apptsLoading && upcomingAppointments.length === 0 && <p>No upcoming appointments.</p>}
        <ul>
          {upcomingAppointments.map((appt) => (
            <li key={appt._id}>
              {new Date(appt.appointmentDate).toLocaleString()} with Dr. {appt.doctor?.name || 'N/A'}
            </li>
          ))}
        </ul>
      </section>
      <section>
        <h2>Recent Prescriptions</h2>
        {prescLoading && <p>Loading prescriptions...</p>}
        {!prescLoading && recentPrescriptions.length === 0 && <p>No recent prescriptions.</p>}
        <ul>
          {recentPrescriptions.map((presc) => (
            <li key={presc._id}>
              Issued on {new Date(presc.issuedDate).toLocaleDateString()} for appointment on{' '}
              {presc.appointment
                ? new Date(presc.appointment.appointmentDate).toLocaleDateString()
                : 'N/A'}
            </li>
          ))}
        </ul>
      </section>
    </section>
  );
};

export default DashboardPage;
