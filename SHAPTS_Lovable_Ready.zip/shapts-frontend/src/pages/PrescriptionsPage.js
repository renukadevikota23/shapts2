import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PrescriptionList from '../components/Prescription/PrescriptionList';
import PrescriptionForm from '../components/Prescription/PrescriptionForm';
import { fetchUserPrescriptions } from '../store/prescriptionSlice';

const PrescriptionsPage = () => {
  const dispatch = useDispatch();
  const { user } = useSelector((state) => state.auth);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    if (user) {
      dispatch(fetchUserPrescriptions(user._id));
    }
  }, [dispatch, user]);

  return (
    <section>
      <h1>Prescriptions</h1>
      <button onClick={() => setShowForm((prev) => !prev)}>
        {showForm ? 'Close Prescription Form' : 'Add Prescription'}
      </button>
      {showForm && <PrescriptionForm onClose={() => setShowForm(false)} />}
      <PrescriptionList />
    </section>
  );
};

export default PrescriptionsPage;
