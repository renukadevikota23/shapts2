# Shapts Frontend

## Project Description

The Shapts frontend is a React application providing a user interface for patients, doctors, and admins to manage healthcare appointments and prescriptions. It integrates with the Shapts backend API and supports authentication, role-based access, and CRUD operations on data.

## Features

- User login and registration
- Protected routes based on authentication
- Dashboard summary of upcoming appointments and prescriptions
- Appointment booking and management
- Prescription creation and viewing
- Responsive and accessible UI

## Prerequisites

- Node.js v16 or higher
- npm
- Backend API running (see shapts-backend README)
- Docker (optional)

## Installation and Setup

1. Clone the repository:

    git clone https://github.com/yourusername/shapts-frontend.git
    cd shapts-frontend

2. Install dependencies:

    npm install

3. Create a `.env` file based on `.env.example`:

    cp .env.example .env

4. Configure environment variables in `.env`:

    - `REACT_APP_API_URL`: URL of the backend API (e.g., http://localhost:5000)

5. Start the development server:

    npm start

## Running Tests

Tests are written using React Testing Library and Jest.

1. Run tests:

    npm test

## Docker Usage

### Build Docker Image

    docker build -t shapts-frontend .

### Run Docker Container

    docker run -d -p 80:80 shapts-frontend

Then access the app at: http://localhost/

## Project Structure

